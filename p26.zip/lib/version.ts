export const APP_VERSION = 'v26';
